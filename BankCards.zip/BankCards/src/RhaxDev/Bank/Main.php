<?php

namespace RhaxDev\Bank;

use pocketmine\Server;
use pocketmine\player\Player;
use pocketmine\command\{Command, CommandSender};
use pocketmine\item\{Item, ItemFactory};
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\utils\Config;
use pocketmine\entity\Entity;
use pocketmine\scheduler\Task;
use pocketmine\entity\Human;
use pocketmine\entity\Skin;
use pocketmine\entity\Location;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\player\PlayerInteractEvent;

use jojoe77777\FormAPI\CustomForm;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\ModalForm;

class Main extends PluginBase implements Listener {
    
    public static $instance;
    
    public static function getInstance(): Main {
        return self::$instance;
    }
    
    public function onEnable() : void{
        self::$instance = $this;
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->saveResource("bank.yml");
        $this->bank = new Config($this->getDataFolder(). "bank.yml", Config::YAML);
        $this->eco = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
        if($this->eco == null) {
            $this->getLogger()->alert("EconomyAPI Plugins Not Found! Stopping Server...");
            $this->getServer()->shutdown();
        }
        $files = ["pay.png", "pay.json", "bank.png", "bank.json"];
        foreach($files as $file) {
            $this->saveResource($file);
        }
        EntityFactory::getInstance()->register(EntityPay::class, function ($world, $nbt) : EntityPay {
            return new EntityPay(EntityDataHelper::parseLocation($nbt, $world), Human::parseSkinNBT($nbt), $nbt);
        }, ["PayEntity"]);
        EntityFactory::getInstance()->register(EntityBank::class, function ($world, $nbt) : EntityBank {
            return new EntityBank(EntityDataHelper::parseLocation($nbt, $world), Human::parseSkinNBT($nbt), $nbt);
        }, ["BankEntity"]);
        $this->getScheduler()->scheduleRepeatingTask(new TaskNPC($this), 20);
    }
    
    public function onCommand(CommandSender $p, Command $cmd, String $label, array $args) : bool{
        if($cmd->getName() === 'bank'){
            $arg = array_shift($args);
            switch($arg){
                case "masuk":
                    $this->loginBank($p);
                break;
                case "buat":
                    $this->registerForm($p);
                break;
                case "kartu":
                    $this->refundCard($p);
                break;
                case "help":
                    $p->sendMessage("§l§b>>> §r§eBankCommand §l§b<<<");
                    $p->sendMessage("§c|| §rKamu Bisa Pergi Ke Mesin ATM Terdekat / Langsung Ke Kantor Bank§c||");
                    $p->sendMessage("§l§6<========[<>]========>");
                break;
                default:
                    $this->bankNPCForm($p);
                break;
            }
            return true;
        }
        return true;
    }
    
    public function refundCard(Player $p){
       if($this->isRegistered($p)){
           $item = ItemFactory::getInstance()->get(339, 0, 1);
           $item->setCustomName("§dKartu §bBCA");
           $item->setLore([$p->getName()]);
           $p->getInventory()->addItem($item);
           $p->sendMessage("§aSukses Membuat Kartu ATM");
       }else{
           $p->sendMessage("§cKamu Belum Membuat Akun Bank");
       }
    }
    
    public function onInteract(PlayerInteractEvent $e){
        $p = $e->getPlayer();
        $b = $e->getBlock();
        $item = $p->getInventory()->getItemInHand();
        if($item->getCustomName() == "§eCardSlider" && $item->getLore() == ["bankitem"]){
            $this->createCreditPay($p, $b);
            $item->setCount($item->getCount() - 1);
            $p->getInventory()->setItemInHand($item);
        }
        if($item->getCustomName() == "§aBankSpawnItem" && $item->getLore() == ["bankitem"]){
            $this->createBankNPC($p);
            $item->setCount($item->getCount() - 1);
            $p->getInventory()->setItemInHand($item);
        }
    }
    
    public function buySliders(Player $p){
	    $form = new CustomForm(function (Player $p, $data = null) {
		    $result = $data;
			if($result === null){
				return true;
			}
			$harga = 5000 * $data[0];
			if($this->eco->myMoney($p) >= $harga) {
			    $this->eco->reduceMoney($p, $harga);
			    $this->giveSlideItem($p, $data[0]);
			    $p->sendMessage("§aSucces Buy SlidersCard §e{$data[0]} §aFor §6{$harga}");
			}else{
			    $p->sendMessage("§cYou Money Not Enough To Buy That!");
			}
        });
        $form->setTitle("Buy Sliders");
        $form->addSlider("Amount:", 1, 64);
        $p->sendForm($form);
        return $form;
    }
    
    public function giveSlideItem(Player $p, int $amount = 1){
        $item = ItemFactory::getInstance()->get(399, 0, $amount);
        $item->setCustomName("§eCardSlider");
        $item->setLore(["bankitem"]);
        $p->getInventory()->addItem($item);
    }
    
    public function giveSpawnItem(Player $p){
	    $form = new CustomForm(function (Player $p, $data = null) {
		    $result = $data;
			if($result === null){
				return true;
			}
			if($p->hasPermission("bank.givespawn")){
			    $item = ItemFactory::getInstance()->get(399, 0, $data[0]);
			    $item->setCustomName("§aBankSpawnItem");
			    $item->setLore(["bankitem"]);
			    $p->getInventory()->addItem($item);
			    $p->sendMessage("§aGive SpawnItem To You!");
			}
        });
        $form->setTitle("Bank Entity Item");
        $form->addSlider("Amount:", 1, 64);
        $p->sendForm($form);
        return $form;
    }
    
    public function createBankNPC(Player $p) {
        $location = $p->getLocation();
        $skin = EntityManager::getSkin("bank.png", "bank.json", "geometry.bank", "BankNPC");
        $nbt = EntityManager::getNBT($p, $location);
        $npc = new EntityBank($location, $skin, $nbt);
        $npc->setSkin($skin);
        $npc->setScale(2);
        $npc->setImmobile(true);
        $npc->setNameTag("Tap To Open Bank!");
        $npc->setHasGravity(false);
        $npc->setForceMovementUpdate(false);
        $npc->setNameTagVisible(true);
        $npc->setNameTagAlwaysVisible(true);
        $npc->sendSkin($this->getServer()->getOnlinePlayers());
        $npc->spawnToAll();
    }
    
    public function createCreditPay(Player $p, $b) {
        $location = new Location($b->getPosition()->getX() + 0.5, $b->getPosition()->getY() + 1, $b->getPosition()->getZ() + 0.5, $b->getPosition()->getWorld(), 0, 0);
        $skin = EntityManager::getSkin("pay.png", "pay.json", "geometry.pay", "EntityPay");
        $nbt = EntityManager::getNBT($p, $location);
        $npc = new EntityPay($location, $skin, $nbt);
        $npc->setSkin($skin);
        $npc->setImmobile(true);
        $npc->setNameTag("Pay Here! To:\n{$p->getName()}");
        $npc->setHasGravity(false);
        $npc->setForceMovementUpdate(false);
        $npc->setNameTagVisible(true);
        $npc->setNameTagAlwaysVisible(true);
        $npc->sendSkin($this->getServer()->getOnlinePlayers());
        $npc->spawnToAll();
    }
    
    public function onHitNPC(EntityDamageByEntityEvent $event) {
        $ent = $event->getEntity();
        $p = $event->getDamager();
		if ($event->getEntity() instanceof EntityPay) {
			$p = $event->getDamager();
			if ($p instanceof Player) {
			    if($p->getInventory()->getItemInHand()->getCustomName() == "§aCreditCards"){
			        $t = explode("\n", $event->getEntity()->getNameTag());
			        $this->payingForm($p, $t[1]);
			    }else{
			        $p->sendMessage("§cSwipe With Card!");
			    }
				$event->cancel(true);
			}else{
                $event->cancel(true);
                $event->getEntity()->setHealth($event->getEntity()->getMaxHealth());
			}
		}
		
		if($ent instanceof EntityBank){
		    if($p instanceof Player){
		        $this->bankNPCForm($p);
		        $event->cancel(true);
		    }else{
                $event->cancel(true);
                $event->getEntity()->setHealth($event->getEntity()->getMaxHealth());
			}
		}
    }
    
    public function bankNPCForm(Player $p){
        $form = new SimpleForm(function (Player $p, int $data = null) {
            $result = $data;
            if($result === null){
                return true;
            }             
            switch($result){
                case 0:
                    $this->loginBank($p);
                break;
                case 1:
                    $this->registerForm($p);
                break;
            }
        });
        $form->setTitle("Kantor Bank");
        $form->setContent("");
        $form->addButton("Masuk", 0, "textures/items/paper");
        $form->addButton("Membuat Akun", 0, "textures/ui/icon_book_writable");
        $p->sendForm($form);
        return $form;
    }
    
    public function payingForm(Player $p, $owner){
        $form = new SimpleForm(function (Player $p, int $data = null) use ($owner) {
            $result = $data;
            if($result === null){
                return true;
            }             
            switch($result){
                case 0:
                    $this->payingWithBank($p, $owner);
                break;
                case 1:
                    $this->payingWithMoney($p, $owner);
                break;
            }
        });
        $form->setTitle("Select Paying Method");
        $form->setContent("");
        $form->addButton("Paying With Bank Money");
        $form->addButton("Paying With Money");
        $p->sendForm($form);
        return $form;
    }
    
    public function payingWithBank(Player $p, $owner) {
	    $form = new CustomForm(function (Player $p, $data = null) use ($owner) {
		    $result = $data;
			if($result === null){
				return true;
			}
            if(trim($data[0]) === ""){
                $p->sendMessage("§cSet The Int Money Value");
                return true;
            }
			$own = $this->getServer()->getPlayerExact($owner);
			if($this->bank->getNested($p->getName().".money") >= $data[0]){
			    if($this->isRegistered($owner)){
			        Api::addMB($own, (int)$data[0]);
			        Api::reduceMB($p, (int)$data[0]);
			        $p->sendMessage("§aSucces Pay/Donate §6".(int)$data[0]." §aTo §e{$owner}");
			        if($own instanceof Player) {
			            $own->sendMessage("§e{$p->getName()} §aHas Pay/Donate To You!");
			        }
			    }else{
			        $p->sendMessage("§cPlayer By That Name Not Registered In Bank!");
			    }
			}else{
			    $p->sendMessage("§cYou Money Bank Not Enough To Pay/Donate");
			}
        });
        $form->setTitle("Pay/Donate With Bank");
        $form->addInput("Amount:", "example: 5000");
        $p->sendForm($form);
        return $form;
    }
    
    public function payingWithMoney(Player $p, $owner) {
	    $form = new CustomForm(function (Player $p, $data = null) use ($owner) {
		    $result = $data;
			if($result === null){
				return true;
			}
            if(trim($data[0]) === ""){
                $p->sendMessage("§cSet The Int Money Value");
                return true;
            }
			$own = $this->getServer()->getPlayerExact($owner);
			if($this->eco->myMoney($p) >= $data[0]){
		        $this->eco->addMoney($own, $data[0]);
		        $this->eco->reduceMoney($p, $data[0]);
			    $p->sendMessage("§aSucces Pay/Donate §6".$data[0]." §aTo §e{$owner}");
			    if($own instanceof Player) {
			        $own->sendMessage("§e{$p->getName()} §aHas Pay/Donate To You!");
			    }
			}else{
			    $p->sendMessage("§cYou Money Not Enough To Pay/Donate");
			}
        });
        $form->setTitle("Pay/Donate With Money");
        $form->addInput("Amount:", "example: 5000");
        $p->sendForm($form);
        return $form;
    }
    
    public function isRegistered($p){
        if($p instanceof Player){
            if(is_numeric($this->bank->getNested($p->getName().".money"))){
                return true;
            }else{
                return false;
            }
        }else{
            if(is_numeric($this->bank->getNested($p.".money"))){
                return true;
            }else{
                return false;
            }
        }
    }
    
    public function randNo(){
        $a = mt_rand(1, 20);
        $b = mt_rand(5, 50);
        $c = mt_rand(2, 106);
        $d = mt_rand(1, 86);
        $e = mt_rand(3, 65);
        $f = mt_rand(6, 68);
        $all = $a + $b + $c + $d + $e + $f;
        $finish = mt_rand($a, $all);
        return $finish;
    }
    
    public function registerForm(Player $p){
	    $form = new CustomForm(function (Player $p, $data = null) {
		    $result = $data;
			if($result === null){
				return true;
			}
			if(trim($data[0]) == ""){
			  $p->sendMessage("§cSilahkan Membuat Sandi Terlebih Dahulu");
			  return true;
			}
			$this->registerBank($p, $data[0]);
        });
        $form->setTitle("Membuat Akun");
        $form->addInput("Sandi:", "Contoh: 12345678");
        $p->sendForm($form);
        return $form;
    }
    
    public function registerBank(Player $p, $pw) {
        if(!$this->isRegistered($p)){
            $this->bank->setNested($p->getName().".money", 0);
            $this->bank->setNested($p->getName().".pw", $pw);
            $this->bank->setNested($p->getName().".id", $this->randNo());
            $this->bank->save();
            $item = ItemFactory::getInstance()->get(339, 0, 1);
            $item->setCustomName("§dKartu §bBCA");
            $item->setLore(Nama: [$p->getName()]);
            $p->getInventory()->addItem($item);
            $p->sendMessage("§aKamu Telah Sukses Membuat Akun Bank \nNama Akun: {$p->getName()}  \nKamu Berhasil Mendapatkan Kartu ATM .. Jika Anda Kehilangan Kartu ATM .. Anda Bisa Langsung Menuju Ke Kantor Bank Pusat Ya");
        }else{
            $p->sendMessage("§cAkun Bank Kamu Sudah Ada");
        }
    }
    
    public function loginBank(Player $p){
        $form = new SimpleForm(function (Player $p, int $data = null) {
            $result = $data;
            if($result === null){
                return true;
            }             
            switch($result){
                case 0:
                    $this->login($p, "card");
                break;
                case 1:
                    $this->login($p, "user");
                break;
            }
        });
        $form->setTitle("Metode");
        $form->setContent("Pilih Metode Login");
        $form->addButton("Melalui ATM \nPegang ATM", 0, "textures/items/paper");
        $form->addButton("Melalui Akun Bank", 0, "textures/ui/Feedback");
        $p->sendForm($form);
        return $form;
    }
    
    public function login(Player $p, string $type){
        switch($type) {
            case "card":
                $item = $p->getInventory()->getItemInHand();
                if($item->getId() == 339 && $item->getMeta() == 0 && $item->getCustomName() == "§dKartu §bBCA"){
                    if($this->isRegistered($p)){
                      if($item->getLore() == [$p->getName()]){
                          $this->openBankInfo($p);
                     }else{
                         $p->sendMessage("§cKartu ATM Ini Bukan Punya Kamu");
                     }
                    }else{
                      $p->sendMessage("§cData Belum Dibuat!!");
                    }
                }else{
                    $p->sendMessage("§cTolong Pegang Kartu ATM Kamu");
                }
            break;
            case "user":
	        $form = new CustomForm(function (Player $p, $data = null) {
		    	$result = $data;
			    if($result === null){
			    	return true;
			    }
			    if(trim($data[0]) == ""){
			      $p->sendMessage("§cSilahkan Masukkan Nama Kamu Terlebih Dahulu");
			      return true;
			    }
			    if(trim($data[1]) == ""){
			      $p->sendMessage("§cSilahkan Masukkan Sandi Kamu Terlebih Dahulu");
			      return true;
			    }
			    $n = $data[0] ?? $p->getName();
			    $pw = $data[1];
			    if($this->isRegistered($n)){
			        if($this->bank->getNested($n.".pw") == $pw){
			            $this->openBankInfo($p);
			        }else{
			            $p->sendMessage("§cSandi Salah");
			        }
			    }else{
			        $p->sendMessage("§cAkun Belum Di Buat");
			    }
            });
            $form->setTitle("Masukkan Nama | Sandi Akun Bank");
            $form->addInput("Akun:", "Contoh: {$p->getName()}");
            $form->addInput("Sandi:", "Contoh: 12345678");
            $p->sendForm($form);
            return $form;
            break;
        }
    }
    
    public function openBankInfo(Player $p){
        $form = new SimpleForm(function (Player $p, int $data = null) {
            $result = $data;
            if($result === null){
                return true;
            }             
            switch($result){
                case 0:
                    $this->transferBank($p);
                break;
                case 1:
                    $this->withdrawBank($p);
                break;
                case 2:
                    $this->saveMoneyBank($p);
                break;
            }
        });
        $money = $this->eco->myMoney($p);
        $mbank = $this->bank->getNested($p->getName().".money");
        $no = $this->bank->getNested($p->getName().".id");
        $form->setTitle("Info Bank");
        $form->setContent("Halo {$p->getName()} \nUang Cash: §6{$money}\n§fSaldo: §6{$mbank}\n\nID Bank: §6{$no}");
        $form->addButton("Transfer", 0, "textures/ui/FriendsIcon");
        $form->addButton("Mengambil Uang", 0, "textures/ui/icon_book_writable");
        $form->addButton("Simpan Uang", 0, "textures/items/map_filled");
        $p->sendForm($form);
        return $form;
    }
    
    public function transferBank(Player $p){
	    $form = new CustomForm(function (Player $p, $data = null) {
		    $result = $data;
			if($result === null){
				return true;
			}
			if(trim($data[0]) === ""){
			  $p->sendMessage("§cMasukkan Jumlah Uang Terlebih Dahulu");
			  return true;
			}
			if(trim($data[1]) === ""){
			  $p->sendMessage("§cMasukkan Nama Seseorang Yang Ingin Kamu Transfer");
			  return true;
			}
			$pmoney = $this->bank->getNested($p->getName().".money");
			$t = $this->getServer()->getPlayerExact($data[1]);
			if($t instanceof Player) {
			    if($pmoney >= $data[0]){
			        Api::reduceMB($p, $data[0]);
			        Api::addMB($t, $data[0]);
			        $p->sendMessage("§aSukses Transfer §6".$data[0]." §aKe §e".$data[1]);
			        $t->sendMessage("§aKamu Mendapatkan §6".$data[0]." §aDari §e".$p->getName());
			    }else{
			        $p->sendMessage("§cSaldo Kamu Tidak Cukup");
			    }
			}else{
			    $p->sendMessage("§cPlayer Tidak Di Temukan/Sedang Offline");
			}
        });
        $money = $this->eco->myMoney($p);
        $mbank = $this->bank->getNested($p->getName().".money");
        $no = $this->bank->getNested($p->getName().".id");
        $form->setTitle("Transfer");
        $form->addInput("Saldo Kamu §6{$mbank} \n§rMasukkan Jumlah Yang Ingin Di Transfer:", "Contoh: 10000");
        $form->addInput("Nama Player Yang Ingin Kamu Transfer:", "Contoh: Player2023");
        $p->sendForm($form);
        return $form;
    }
    
    public function withdrawBank(Player $p){
	    $form = new CustomForm(function (Player $p, $data = null) {
		    $result = $data;
			if($result === null){
				return true;
			}
			if(trim($data[0]) === ""){
			  $p->sendMessage("§cMasukkan Jumlah Yang Ingin Kamu Ambil");
			  return true;
			}
			$pmoney = $this->bank->getNested($p->getName().".money");
			if($pmoney >= $data[0]){
			    Api::reduceMB($p, $data[0]);
			    $this->eco->addMoney($p, $data[0]);
			    $p->sendMessage("§aSukses Mengambil §6".$data[0]." §aSaldo");
			}else{
			    $p->sendMessage("§cSaldo Kamu Tidak Cukup");
			}
        });
        $money = $this->eco->myMoney($p);
        $mbank = $this->bank->getNested($p->getName().".money");
        $no = $this->bank->getNested($p->getName().".id");
        $form->setTitle("Mengambil Uang");
        $form->addInput("Saldo Kamu: §6{$mbank} \n§rUang Kamu: §6{$money} \n§rMasukkan Jumlah Saldo", "Contoh: 10000");
        $p->sendForm($form);
        return $form;
    }
    
    public function saveMoneyBank(Player $p) {
	    $form = new CustomForm(function (Player $p, $data = null) {
		    $result = $data;
			if($result === null){
				return true;
			}
			if(trim($data[0]) === ""){
			  $p->sendMessage("§cMasukkan Jumlah Uang Yang Ingin Kamu Simpan");
				return true;
	    }
			$pmoney = $this->bank->getNested($p->getName().".money");
			$money = $this->eco->myMoney($p);
			if($money >= $data[0]){
			    $this->eco->reduceMoney($p, $data[0]);
			    Api::addMB($p, $data[0]);
			    $p->sendMessage("§aSukses Mengirim §6".$data[0]." §aUang Ke Bank");
			}else{
			    $p->sendMessage("§cUang Kamu Tidak Cukup Untuk Top Up");
			}
        });
        $money = $this->eco->myMoney($p);
        $mbank = $this->bank->getNested($p->getName().".money");
        $no = $this->bank->getNested($p->getName().".id");
        $form->setTitle("Simpan Uang");
        $form->addInput("Uang Kamu: §6{$money}§r\nSaldo Kamu: §6{$mbank}§r \nJumlah Uang Yang Ingin Kamu Simpan", "Contoh: 10000");
        $p->sendForm($form);
        return $form;
    }
}

class Api {
    
    public static function addMB(Player $p, $int){
        $m = Main::getInstance()->bank->getNested($p->getName().".money");
        Main::getInstance()->bank->setNested($p->getName().".money", $m + $int);
        Main::getInstance()->bank->save();
    }
    
    public static function reduceMB(Player $p, $int){
        $m = Main::getInstance()->bank->getNested($p->getName().".money");
        Main::getInstance()->bank->setNested($p->getName().".money", $m - $int);
        Main::getInstance()->bank->save();
    }
}

class TaskNPC extends Task {
  
  public function __construct(Main $pl){
    $this->pl = $pl;
  }
  
  public function onRun() : void {
    foreach($this->pl->getServer()->getWorldManager()->getWorlds() as $w){
      foreach($w->getEntities() as $ent){
        if($ent instanceof EntityBank){
          $ent->setNameTagAlwaysVisible(true);
          $ent->setNameTagVisible(true);
          $ent->setScale(2);
        }
        if($ent instanceof EntityPay){
          $ent->setNameTagAlwaysVisible(true);
          $ent->setNameTagVisible(true);
        }
      }
    }
  }
}
