<?php

namespace RhaxDev\Bank;

use pocketmine\entity\Human;
use pocketmine\entity\Skin;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\world\World;

class EntityPay extends Human{
    
}